
package ec.edu.espe.view;

/**
 *
 * @author Alex Cuzco, HoneyBadgers, DCCO-ESPE
 */
public class View {
     public void displayInformation(String information) {
        System.out.println(information);
    }
}

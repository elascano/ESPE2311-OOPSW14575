
package ec.edu.espe.model;

/**
 *
 * @author Alex Cuzco, HoneyBadgers, DCCO-ESPE
 */
public class D extends A{
    
}

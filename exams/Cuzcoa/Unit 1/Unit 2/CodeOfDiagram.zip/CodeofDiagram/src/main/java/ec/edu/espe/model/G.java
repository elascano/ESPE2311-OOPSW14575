
package ec.edu.espe.model;

/**
 *
 * @author Alex Cuzco, HoneyBadgers, DCCO-ESPE
 */
public class G implements H{
    
}
